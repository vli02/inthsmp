This directory contains three documents:

1. umlhsm.pdf

  Introduction of UML Hierarchical State Machine
  
2. inthsmp.pdf

  Introduction of Intuitive Hierarchical State Machine Programming
  
3. hsmp-spec.def

  Intuitive Hierarchical State Machine Programming Specification
