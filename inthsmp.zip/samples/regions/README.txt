Orthogonal regions sample:
==========================
1. regions.def
        Demostration of orthogonal regions as shown on diagram regions.png.
