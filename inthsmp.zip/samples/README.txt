The hierarchical state machine sample code.

1. keypress - three sample code of a keypress handling state machine.
2. regions  - a orthogonal regions state machine sample.
